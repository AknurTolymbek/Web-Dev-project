import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-drinks',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './drinks.component.html',
  styleUrls: ['./drinks.component.css']
})
export class DrinksComponent implements OnInit {
  drinks: any[] = [];

  constructor(private pizzaService: PizzaService) {}

  ngOnInit() {
    this.pizzaService.getDrinks().subscribe({
      next: (data: any[]) => {
        this.drinks = data;
      },
      error: (err: any) => {
        console.error('Failed to load drinks:', err);
      }
    });
  }

  addToCart(drink: any) {
    this.pizzaService.addToCart({ drink: drink.id, quantity: 1 });
    alert(`${drink.name} added to cart!`);
  }
}