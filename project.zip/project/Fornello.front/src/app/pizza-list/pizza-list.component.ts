import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-pizza-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pizza-list.component.html',
  styleUrls: ['./pizza-list.component.css']
})
export class PizzaListComponent implements OnInit {
  pizzas: any[] = [];

  constructor(private pizzaService: PizzaService) {}

  ngOnInit() {
    this.pizzaService.getPizzas().subscribe({
      next: (data: any[]) => {
        this.pizzas = data;
      },
      error: (err: any) => {
        console.error('Failed to load pizzas:', err);
      }
    });
  }

  addToCart(pizza: any) {
    this.pizzaService.addToCart({ pizza: pizza.id, quantity: 1 });
    alert(`${pizza.name} added to cart!`);
  }
}