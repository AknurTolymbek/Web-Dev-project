import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface Pizza {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
}

export interface Drink {
  id: number;
  name: string;
  price: number;
  image: string;
}

export interface Sauce {
  id: number;
  name: string;
  price: number;
  image: string;
}

@Injectable({
  providedIn: 'root'
})
export class PizzaService {
  private apiUrl = 'http://localhost:8000/api/';
  private cart: any[] = [];
  private itemsCache: { pizzas: Pizza[], drinks: Drink[], sauces: Sauce[] } = {
    pizzas: [],
    drinks: [],
    sauces: []
  };

  constructor(private http: HttpClient) {
    this.loadItems();
  }

  private loadItems() {
    this.getPizzas().subscribe({
      next: (data: Pizza[]) => {
        console.log('Pizzas loaded:', data);
        this.itemsCache.pizzas = data;
      },
      error: (err: any) => console.error('Failed to load pizzas:', err)
    });
    this.getDrinks().subscribe({
      next: (data: Drink[]) => {
        console.log('Drinks loaded:', data);
        this.itemsCache.drinks = data;
      },
      error: (err: any) => console.error('Failed to load drinks:', err)
    });
    this.getSauces().subscribe({
      next: (data: Sauce[]) => {
        console.log('Sauces loaded:', data);
        this.itemsCache.sauces = data;
      },
      error: (err: any) => console.error('Failed to load sauces:', err)
    });
  }

  getPizzas(): Observable<Pizza[]> {
    return this.http.get<{ results: Pizza[] }>(`${this.apiUrl}pizzas/`).pipe(
      map(response => response.results)
    );
  }

  getDrinks(): Observable<Drink[]> {
    return this.http.get<{ results: Drink[] }>(`${this.apiUrl}drinks/`).pipe(
      map(response => response.results)
    );
  }

  getSauces(): Observable<Sauce[]> {
    return this.http.get<{ results: Sauce[] }>(`${this.apiUrl}sauces/`).pipe(
      map(response => response.results)
    );
  }

  getItemDetails(itemId: number, type: string): any {
    if (type === 'pizza') {
      return this.itemsCache.pizzas.find(item => item.id === itemId) || {};
    } else if (type === 'drink') {
      return this.itemsCache.drinks.find(item => item.id === itemId) || {};
    } else if (type === 'sauce') {
      return this.itemsCache.sauces.find(item => item.id === itemId) || {};
    }
    return {};
  }

  addToCart(item: any) {
    const existingItem = this.cart.find(cartItem =>
      (cartItem.pizza && cartItem.pizza === item.pizza) ||
      (cartItem.drink && cartItem.drink === item.drink) ||
      (cartItem.sauce && cartItem.sauce === item.sauce)
    );
    if (existingItem) {
      existingItem.quantity += item.quantity;
    } else {
      this.cart.push(item);
    }
  }

  getCart(): any[] {
    return this.cart;
  }

  updateCart(cart: any[]) {
    this.cart = cart;
  }

  clearCart() {
    this.cart = [];
  }

  createOrder(order: any): Observable<any> {
    return this.http.post(`${this.apiUrl}order/`, order);
  }
}