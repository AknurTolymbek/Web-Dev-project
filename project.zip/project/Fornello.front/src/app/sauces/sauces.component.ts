import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-sauces',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sauces.component.html',
  styleUrls: ['./sauces.component.css']
})
export class SaucesComponent implements OnInit {
  sauces: any[] = [];

  constructor(private pizzaService: PizzaService) {}

  ngOnInit() {
    this.pizzaService.getSauces().subscribe({
      next: (data: any[]) => {
        this.sauces = data;
      },
      error: (err: any) => {
        console.error('Failed to load sauces:', err);
      }
    });
  }

  addToCart(sauce: any) {
    this.pizzaService.addToCart({ sauce: sauce.id, quantity: 1 });
    alert(`${sauce.name} added to cart!`);
  }
}