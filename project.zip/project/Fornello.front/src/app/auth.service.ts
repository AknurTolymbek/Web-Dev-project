import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:8000/api/';
  private loggedIn = new BehaviorSubject<boolean>(false);
  private user = new BehaviorSubject<any>(null);
  private token: string | null = null;

  constructor(
    private http: HttpClient,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    if (isPlatformBrowser(this.platformId)) {
      const storedToken = localStorage.getItem('access_token');
      if (storedToken) {
        this.token = storedToken;
        this.loggedIn.next(true);
        this.fetchUserProfile();
      }
    }
  }

  register(user: any): Observable<any> {
    return this.http.post(`${this.apiUrl}register/`, user).pipe(
      tap((response: any) => {
        if (response.access) {
          this.token = response.access;
          if (this.token && isPlatformBrowser(this.platformId)) {
            localStorage.setItem('access_token', this.token);
            localStorage.setItem('refresh_token', response.refresh);
          }
          this.loggedIn.next(true);
          if (isPlatformBrowser(this.platformId)) {
            this.fetchUserProfile();
          }
          this.router.navigate(['/cart']);
        }
      })
    );
  }

  login(user: any): Observable<any> {
    return this.http.post(`${this.apiUrl}token/`, user).pipe(
      tap((response: any) => {
        if (response.access) {
          this.token = response.access;
          if (this.token && isPlatformBrowser(this.platformId)) {
            localStorage.setItem('access_token', this.token);
            localStorage.setItem('refresh_token', response.refresh);
          }
          this.loggedIn.next(true);
          if (isPlatformBrowser(this.platformId)) {
            this.fetchUserProfile();
          }
          this.router.navigate(['/cart']);
        }
      })
    );
  }

  logout() {
    this.token = null;
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
    }
    this.loggedIn.next(false);
    this.user.next(null);
    this.router.navigate(['/']);
  }

  isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  getUser(): Observable<any> {
    return this.user.asObservable();
  }

  getToken(): string | null {
    return this.token;
  }

  private fetchUserProfile() {
    if (!this.token) return;
    this.http.get(`${this.apiUrl}profile/`, {
      headers: { Authorization: `Bearer ${this.token}` }
    }).subscribe({
      next: (userData: any) => {
        this.user.next(userData);
      },
      error: (err: any) => {
        console.error('Failed to fetch user profile:', err);
        this.logout();
      }
    });
  }
}