import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PizzaService } from '../pizza.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: any[] = [];
  user: any = null;

  constructor(private pizzaService: PizzaService, private authService: AuthService) {}

  ngOnInit() {
    this.authService.getUser().subscribe(user => {
      this.user = user;
    });
    this.cart = this.pizzaService.getCart();
  }

  getItemName(item: any): string {
    if (item.pizza) {
      const pizza = this.pizzaService.getItemDetails(item.pizza, 'pizza');
      return pizza.name || 'Unknown Pizza';
    } else if (item.drink) {
      const drink = this.pizzaService.getItemDetails(item.drink, 'drink');
      return drink.name || 'Unknown Drink';
    } else if (item.sauce) {
      const sauce = this.pizzaService.getItemDetails(item.sauce, 'sauce');
      return sauce.name || 'Unknown Sauce';
    }
    return 'Unknown Item';
  }

  getItemPrice(item: any): string {
    if (item.pizza) {
      const pizza = this.pizzaService.getItemDetails(item.pizza, 'pizza');
      return pizza.price || '0.00';
    } else if (item.drink) {
      const drink = this.pizzaService.getItemDetails(item.drink, 'drink');
      return drink.price || '0.00';
    } else if (item.sauce) {
      const sauce = this.pizzaService.getItemDetails(item.sauce, 'sauce');
      return sauce.price || '0.00';
    }
    return '0.00';
  }

  getItemImage(item: any): string {
    if (item.pizza) {
      const pizza = this.pizzaService.getItemDetails(item.pizza, 'pizza');
      return pizza.image || '';
    } else if (item.drink) {
      const drink = this.pizzaService.getItemDetails(item.drink, 'drink');
      return drink.image || '';
    } else if (item.sauce) {
      const sauce = this.pizzaService.getItemDetails(item.sauce, 'sauce');
      return sauce.image || '';
    }
    return '';
  }

  removeFromCart(item: any) {
    this.cart = this.cart.filter(cartItem => cartItem !== item);
    this.pizzaService.updateCart(this.cart);
  }

  createOrder() {
    const order = { items: this.cart };
    this.pizzaService.createOrder(order).subscribe({
      next: (response: any) => {
        alert('Order created successfully!');
        this.pizzaService.clearCart();
        this.cart = [];
      },
      error: (err: any) => {
        console.error('Failed to create order:', err);
        alert('Failed to create order. Please try again.');
      }
    });
  }
}