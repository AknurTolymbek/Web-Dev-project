import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PizzaListComponent } from './pizza-list/pizza-list.component';
import { SaucesComponent } from './sauces/sauces.component';
import { DrinksComponent } from './drinks/drinks.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'pizzas', component: PizzaListComponent },
  { path: 'drinks', component: DrinksComponent },
  { path: 'sauces', component: SaucesComponent },
  { path: 'menu', component: PizzaListComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
