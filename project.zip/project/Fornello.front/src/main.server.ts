import { renderApplication } from '@angular/platform-server';
   import { bootstrapApplication } from '@angular/platform-browser';
   import { AppComponent } from './app/app.component';
   import { appConfig } from './app/app.config';

   const bootstrap = () => bootstrapApplication(AppComponent, appConfig);

   export default async function render() {
     return await renderApplication(bootstrap, {
       document: '<app-root></app-root>'
     });
   }